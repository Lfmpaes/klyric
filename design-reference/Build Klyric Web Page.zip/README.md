
  # Build Klyric Web Page

  This is a code bundle for Build Klyric Web Page. The original project is available at https://www.figma.com/design/vYUpxrjomqsS4mMZQIeA5m/Build-Klyric-Web-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  