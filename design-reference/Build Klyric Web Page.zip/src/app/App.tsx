import { Download, Github, ArrowRight, Music2, ChevronRight } from "lucide-react";

// ─── Design tokens ────────────────────────────────────────────────────────────
const T = {
  bg: "#131313",
  canvas: "#0e0e0e",
  darkBlue: "#111827",
  titleBar: "#201f1f",
  secondary: "#2a2a2a",
  cyan: "#06b6d4",
  cyanBright: "#4cd7f6",
  headline: "#e5e2e1",
  body: "#bcc9cd",
  border: "#3d494c",
  mutedBorder: "#1f2937",
} as const;

// ─── Sub-components ───────────────────────────────────────────────────────────

function KlyricIcon() {
  return (
    <svg
      width="54"
      height="54"
      viewBox="0 0 54 54"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <rect
        x="1"
        y="1"
        width="52"
        height="52"
        rx="3"
        stroke={T.border}
        strokeWidth="1"
        fill={T.darkBlue}
      />
      {/* Terminal prompt */}
      <text
        x="9"
        y="29"
        fontFamily="'Geist Mono', monospace"
        fontSize="12"
        fill={T.cyan}
        fontWeight="600"
      >
        &gt;_
      </text>
      {/* Musical note */}
      <line x1="36" y1="18" x2="36" y2="30" stroke={T.cyan} strokeWidth="1.5" strokeLinecap="round" />
      <line x1="36" y1="18" x2="42" y2="16" stroke={T.cyan} strokeWidth="1.5" strokeLinecap="round" />
      <ellipse cx="34" cy="31" rx="3" ry="2" fill={T.cyan} transform="rotate(-15 34 31)" />
      {/* Lyric line indicators */}
      <line x1="9" y1="36" x2="32" y2="36" stroke={T.border} strokeWidth="1" strokeLinecap="round" />
      <line x1="9" y1="40" x2="26" y2="40" stroke={T.border} strokeWidth="1" strokeLinecap="round" />
    </svg>
  );
}

function BrandLogo() {
  return (
    <div className="flex items-center gap-2.5" style={{ gap: "10px" }}>
      <svg
        width="20"
        height="20"
        viewBox="0 0 20 20"
        fill="none"
        aria-hidden="true"
      >
        {/* Prompt > */}
        <path d="M2 6 L6 10 L2 14" stroke={T.cyan} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        {/* Note stem */}
        <line x1="13" y1="5" x2="13" y2="13" stroke={T.cyan} strokeWidth="1.5" strokeLinecap="round" />
        <line x1="13" y1="5" x2="17" y2="4" stroke={T.cyan} strokeWidth="1.5" strokeLinecap="round" />
        <ellipse cx="11.5" cy="13.5" rx="2" ry="1.5" fill={T.cyan} transform="rotate(-15 11.5 13.5)" />
      </svg>
      <span
        style={{
          fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
          fontSize: "15px",
          fontWeight: 600,
          letterSpacing: "-0.01em",
        }}
      >
        <span style={{ color: T.cyan }}>K</span>
        <span style={{ color: T.headline }}>lyric</span>
      </span>
    </div>
  );
}

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="transition-colors duration-150 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 rounded-sm"
      style={{
        color: T.body,
        fontSize: "11px",
        textTransform: "uppercase",
        letterSpacing: "0.08em",
        fontWeight: 500,
        textDecoration: "none",
        fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
        // @ts-ignore
        "--hover-color": T.cyanBright,
        outlineColor: T.cyan,
      }}
      onMouseEnter={(e) => ((e.target as HTMLElement).style.color = T.cyanBright)}
      onMouseLeave={(e) => ((e.target as HTMLElement).style.color = T.body)}
      onFocus={(e) => ((e.target as HTMLElement).style.color = T.cyanBright)}
      onBlur={(e) => ((e.target as HTMLElement).style.color = T.body)}
    >
      {children}
    </a>
  );
}

function Badge({ children }: { children: string }) {
  return (
    <span
      style={{
        background: T.darkBlue,
        border: `1px solid ${T.mutedBorder}`,
        color: T.cyan,
        fontSize: "11px",
        fontFamily: "'Geist Mono', 'JetBrains Mono', monospace",
        fontWeight: 500,
        letterSpacing: "0.06em",
        padding: "3px 8px",
        borderRadius: "4px",
        textTransform: "uppercase" as const,
        display: "inline-block",
      }}
    >
      {children}
    </span>
  );
}

function PlasmaPreview() {
  return (
    <div>
      <p
        style={{
          color: T.body,
          fontSize: "10px",
          fontFamily: "'Geist Mono', monospace",
          letterSpacing: "0.1em",
          textTransform: "uppercase" as const,
          marginBottom: "8px",
          opacity: 0.7,
        }}
      >
        Plasma panel preview
      </p>
      {/* Desktop window frame */}
      <div
        style={{
          background: "#1a1e2a",
          border: `1px solid ${T.border}`,
          borderRadius: "5px",
          overflow: "hidden",
          width: "100%",
          maxWidth: "380px",
        }}
      >
        {/* Plasma panel */}
        <div
          style={{
            background: "#1e1e2e",
            borderBottom: `1px solid #2d3250`,
            height: "38px",
            display: "flex",
            alignItems: "center",
            padding: "0 10px",
            gap: "6px",
          }}
        >
          {/* App icons */}
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              style={{
                width: "20px",
                height: "20px",
                borderRadius: "4px",
                background: "#2d3250",
                flexShrink: 0,
                opacity: 0.7,
              }}
            />
          ))}
          {/* Spacer */}
          <div style={{ flex: 1 }} />
          {/* KLyric applet */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "5px",
              background: "rgba(6,182,212,0.08)",
              border: `1px solid rgba(6,182,212,0.3)`,
              borderRadius: "3px",
              padding: "3px 8px",
              maxWidth: "180px",
            }}
          >
            <Music2 size={10} color={T.cyan} />
            <span
              style={{
                color: T.cyanBright,
                fontSize: "11px",
                fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              The city moves in perfect time
            </span>
          </div>
          {/* Spacer */}
          <div style={{ flex: 1 }} />
          {/* System tray */}
          <div style={{ display: "flex", gap: "4px" }}>
            {[0, 1].map((i) => (
              <div
                key={i}
                style={{
                  width: "16px",
                  height: "16px",
                  borderRadius: "2px",
                  background: "#2d3250",
                  opacity: 0.6,
                }}
              />
            ))}
            <div
              style={{
                fontSize: "10px",
                color: "#6b7a99",
                fontFamily: "'Geist Mono', monospace",
                lineHeight: "16px",
              }}
            >
              23:41
            </div>
          </div>
        </div>

        {/* Desktop area */}
        <div
          style={{
            background: "#141520",
            padding: "12px",
            minHeight: "60px",
            display: "flex",
            alignItems: "flex-start",
            justifyContent: "flex-end",
          }}
        >
          {/* KLyric popup */}
          <div
            style={{
              background: "#1e2235",
              border: `1px solid #2d3250`,
              borderRadius: "4px",
              padding: "12px",
              width: "210px",
              flexShrink: 0,
            }}
          >
            {/* Status row */}
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "5px",
                marginBottom: "8px",
                paddingBottom: "8px",
                borderBottom: `1px solid #252840`,
              }}
            >
              <div
                style={{
                  width: "5px",
                  height: "5px",
                  borderRadius: "50%",
                  background: "#22c55e",
                  flexShrink: 0,
                }}
              />
              <span
                style={{
                  color: "#6b7a99",
                  fontSize: "9px",
                  fontFamily: "'Geist Mono', monospace",
                  letterSpacing: "0.05em",
                  textTransform: "uppercase" as const,
                }}
              >
                Connected locally
              </span>
            </div>

            {/* Track info */}
            <div style={{ marginBottom: "10px" }}>
              <p
                style={{
                  color: T.headline,
                  fontSize: "11px",
                  fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
                  fontWeight: 600,
                  margin: 0,
                  lineHeight: 1.3,
                }}
              >
                Midnight Signals
              </p>
              <p
                style={{
                  color: "#6b7a99",
                  fontSize: "10px",
                  fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
                  margin: 0,
                  lineHeight: 1.3,
                }}
              >
                Demo Artist
              </p>
            </div>

            {/* Lyric lines */}
            <div style={{ display: "flex", flexDirection: "column", gap: "2px" }}>
              {/* Previous */}
              <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                <div style={{ width: "2px", height: "14px", background: "transparent", flexShrink: 0 }} />
                <span
                  style={{
                    color: "#3d4d5c",
                    fontSize: "10px",
                    fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
                    lineHeight: 1.4,
                  }}
                >
                  Signals fade across the wire
                </span>
              </div>
              {/* Current */}
              <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                <div
                  style={{
                    width: "2px",
                    height: "16px",
                    background: T.cyan,
                    borderRadius: "1px",
                    flexShrink: 0,
                  }}
                />
                <span
                  style={{
                    color: T.cyanBright,
                    fontSize: "11px",
                    fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
                    fontWeight: 600,
                    lineHeight: 1.4,
                  }}
                >
                  The city moves in perfect time
                </span>
              </div>
              {/* Next */}
              <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                <div style={{ width: "2px", height: "14px", background: "transparent", flexShrink: 0 }} />
                <span
                  style={{
                    color: "#4d5e6e",
                    fontSize: "10px",
                    fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
                    lineHeight: 1.4,
                  }}
                >
                  Where silence meets the neon light
                </span>
              </div>
            </div>

            {/* Footer */}
            <div
              style={{
                marginTop: "10px",
                paddingTop: "8px",
                borderTop: `1px solid #252840`,
              }}
            >
              <span
                style={{
                  color: "#3d4d5c",
                  fontSize: "9px",
                  fontFamily: "'Geist Mono', monospace",
                  letterSpacing: "0.03em",
                }}
              >
                Loopback bridge · No cloud connection
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ArchStrip() {
  const steps = [
    {
      label: "Cider plugin",
      desc: "Reads the active line",
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
          <rect x="1" y="1" width="14" height="14" rx="2" stroke={T.border} strokeWidth="1" />
          <path d="M5 8 L8 5 L11 8" stroke={T.cyan} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M8 5 L8 11" stroke={T.cyan} strokeWidth="1.2" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      label: "Local bridge",
      desc: "Keeps current state in memory",
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
          <rect x="1" y="1" width="14" height="14" rx="2" stroke={T.border} strokeWidth="1" />
          <circle cx="8" cy="8" r="3" stroke={T.cyan} strokeWidth="1.2" />
          <line x1="8" y1="3" x2="8" y2="5" stroke={T.cyan} strokeWidth="1.2" strokeLinecap="round" />
          <line x1="8" y1="11" x2="8" y2="13" stroke={T.cyan} strokeWidth="1.2" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      label: "Plasma widget",
      desc: "Renders it in your panel",
      icon: (
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
          <rect x="1" y="1" width="14" height="14" rx="2" stroke={T.border} strokeWidth="1" />
          <rect x="3" y="3" width="10" height="4" rx="1" stroke={T.cyan} strokeWidth="1" />
          <line x1="3" y1="10" x2="10" y2="10" stroke={T.border} strokeWidth="1" strokeLinecap="round" />
          <line x1="3" y1="12.5" x2="8" y2="12.5" stroke={T.border} strokeWidth="1" strokeLinecap="round" />
        </svg>
      ),
    },
  ];

  return (
    <div>
      <div
        style={{
          borderTop: `1px solid ${T.border}`,
          marginBottom: "20px",
        }}
      />
      {/* Steps row */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "0",
          flexWrap: "wrap" as const,
        }}
      >
        {steps.map((step, i) => (
          <div key={step.label} style={{ display: "flex", alignItems: "center", flex: 1, minWidth: "160px" }}>
            <div
              style={{
                display: "flex",
                flexDirection: "column" as const,
                gap: "4px",
                flex: 1,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "7px" }}>
                {step.icon}
                <span
                  style={{
                    color: T.headline,
                    fontSize: "12px",
                    fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
                    fontWeight: 600,
                    letterSpacing: "0.02em",
                  }}
                >
                  {step.label}
                </span>
              </div>
              <p
                style={{
                  color: T.body,
                  fontSize: "11px",
                  fontFamily: "'Geist', 'Inter', system-ui, sans-serif",
                  margin: 0,
                  paddingLeft: "23px",
                  opacity: 0.7,
                }}
              >
                {step.desc}
              </p>
            </div>
            {i < steps.length - 1 && (
              <div style={{ display: "flex", alignItems: "center", padding: "0 12px", flexShrink: 0 }}>
                <svg width="28" height="10" viewBox="0 0 28 10" fill="none" aria-hidden="true">
                  <line x1="0" y1="5" x2="22" y2="5" stroke={T.cyan} strokeWidth="1" strokeDasharray="3 2" />
                  <path d="M20 2 L26 5 L20 8" stroke={T.cyan} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </div>
            )}
          </div>
        ))}
      </div>
      {/* Supporting statement */}
      <p
        style={{
          color: T.body,
          fontSize: "11px",
          fontFamily: "'Geist Mono', monospace",
          marginTop: "14px",
          opacity: 0.6,
          letterSpacing: "0.03em",
        }}
      >
        No account. No remote service. No lyric uploads.
      </p>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const fontStack = "'Geist', 'Inter', system-ui, sans-serif";
  const monoStack = "'Geist Mono', 'JetBrains Mono', monospace";

  // Dotted grid background
  const gridBg = {
    backgroundImage: `radial-gradient(${T.cyan} 1px, transparent 1px)`,
    backgroundSize: "24px 24px",
  };

  return (
    <div
      style={{
        background: T.bg,
        minHeight: "100vh",
        fontFamily: fontStack,
        color: T.headline,
        position: "relative",
      }}
    >
      {/* Dotted grid overlay */}
      <div
        aria-hidden="true"
        style={{
          position: "fixed",
          inset: 0,
          ...gridBg,
          opacity: 0.025,
          pointerEvents: "none",
          zIndex: 0,
        }}
      />

      {/* Scroll container */}
      <div style={{ position: "relative", zIndex: 1 }}>
        {/* ── Header ─────────────────────────────────────────────────── */}
        <header
          style={{
            height: "64px",
            borderBottom: `1px solid ${T.border}`,
            display: "flex",
            alignItems: "center",
          }}
        >
          <div
            style={{
              maxWidth: "920px",
              margin: "0 auto",
              width: "100%",
              padding: "0 24px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <BrandLogo />
            <nav aria-label="Primary navigation">
              <div style={{ display: "flex", alignItems: "center", gap: "28px" }}>
                <NavLink href="https://github.com/Lfmpaes/klyric/blob/main/docs/installation.md">
                  Documentation
                </NavLink>
                <NavLink href="https://github.com/Lfmpaes/klyric">
                  GitHub
                </NavLink>
              </div>
            </nav>
          </div>
        </header>

        {/* ── Main ───────────────────────────────────────────────────── */}
        <main>
          <div
            style={{
              maxWidth: "920px",
              margin: "0 auto",
              padding: "32px 24px 40px",
            }}
          >
            {/* Terminal card */}
            <article
              style={{
                background: T.canvas,
                border: `1px solid ${T.border}`,
                borderRadius: "4px",
                overflow: "hidden",
                minWidth: 0,
              }}
            >
              {/* Title bar */}
              <div
                style={{
                  background: T.titleBar,
                  borderBottom: `1px solid ${T.border}`,
                  height: "40px",
                  display: "flex",
                  alignItems: "center",
                  padding: "0 14px",
                }}
              >
                {/* Window controls */}
                <div style={{ display: "flex", gap: "6px", marginRight: "auto" }}>
                  {[0, 1, 2].map((i) => (
                    <div
                      key={i}
                      aria-hidden="true"
                      style={{
                        width: "11px",
                        height: "11px",
                        borderRadius: "50%",
                        background: "#3d3d3d",
                      }}
                    />
                  ))}
                </div>
                <div style={{ flex: 1 }} />
                {/* Title */}
                <span
                  style={{
                    color: T.body,
                    fontSize: "11px",
                    fontFamily: monoStack,
                    opacity: 0.6,
                    letterSpacing: "0.04em",
                  }}
                >
                  klyric.sh
                </span>
              </div>

              {/* Terminal body */}
              <div style={{ padding: "clamp(20px, 4.8vw, 44px)" }}>
                {/* Two-column layout */}
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "54fr 46fr",
                    gap: "44px",
                    alignItems: "center",
                    minWidth: 0,
                  }}
                  className="hero-grid"
                >
                  {/* ── Left column ─── */}
                  <section aria-label="Product overview" style={{ minWidth: 0 }}>
                    {/* Icon */}
                    <div style={{ marginBottom: "18px" }}>
                      <KlyricIcon />
                    </div>

                    {/* Eyebrow */}
                    <p
                      style={{
                        color: T.cyan,
                        fontSize: "11px",
                        fontFamily: fontStack,
                        fontWeight: 600,
                        letterSpacing: "0.05em",
                        textTransform: "uppercase" as const,
                        margin: "0 0 12px 0",
                      }}
                    >
                      KDE Plasma 6 × Cider
                    </p>

                    {/* Headline */}
                    <h1
                      style={{
                        color: T.headline,
                        fontSize: "clamp(30px, 3vw, 42px)",
                        fontWeight: 780,
                        lineHeight: 1.15,
                        letterSpacing: "-0.025em",
                        margin: "0 0 16px 0",
                        fontFamily: fontStack,
                      }}
                    >
                      Synchronized lyrics, right in your Plasma panel.
                    </h1>

                    {/* Description */}
                    <p
                      style={{
                        color: T.body,
                        fontSize: "15px",
                        lineHeight: 1.65,
                        margin: "0 0 28px 0",
                        maxWidth: "100%",
                        fontFamily: fontStack,
                      }}
                    >
                      KLyric connects Cider to a lightweight KDE Plasma 6 widget, keeping
                      the active lyric line visible without leaving your desktop. Everything
                      stays on your machine.
                    </p>

                    {/* CTA group */}
                    <div
                      style={{
                        display: "flex",
                        flexWrap: "wrap" as const,
                        gap: "10px",
                        marginBottom: "16px",
                        alignItems: "center",
                      }}
                    >
                      {/* Primary CTA */}
                      <a
                        href="https://github.com/Lfmpaes/klyric/releases/latest"
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label="Download latest KLyric release"
                        style={{
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "7px",
                          background: T.darkBlue,
                          border: `1px solid ${T.cyan}`,
                          color: T.cyan,
                          fontSize: "13px",
                          fontFamily: fontStack,
                          fontWeight: 500,
                          letterSpacing: "0.01em",
                          padding: "0 16px",
                          height: "42px",
                          borderRadius: "3px",
                          textDecoration: "none",
                          transition: "border-color 150ms, color 150ms",
                          flexShrink: 0,
                          flex: "1 1 auto",
                          justifyContent: "center",
                        }}
                        onMouseEnter={(e) => {
                          const el = e.currentTarget;
                          el.style.borderColor = T.cyanBright;
                          el.style.color = T.cyanBright;
                        }}
                        onMouseLeave={(e) => {
                          const el = e.currentTarget;
                          el.style.borderColor = T.cyan;
                          el.style.color = T.cyan;
                        }}
                        onFocus={(e) => {
                          const el = e.currentTarget;
                          el.style.borderColor = T.cyanBright;
                          el.style.color = T.cyanBright;
                          el.style.outline = `2px solid ${T.cyan}`;
                          el.style.outlineOffset = "2px";
                        }}
                        onBlur={(e) => {
                          const el = e.currentTarget;
                          el.style.borderColor = T.cyan;
                          el.style.color = T.cyan;
                          el.style.outline = "none";
                        }}
                      >
                        <Download size={14} />
                        Download latest release
                      </a>

                      {/* Secondary CTA */}
                      <a
                        href="https://github.com/Lfmpaes/klyric"
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label="View KLyric source code on GitHub"
                        style={{
                          display: "inline-flex",
                          alignItems: "center",
                          gap: "7px",
                          background: "transparent",
                          border: `1px solid ${T.border}`,
                          color: T.body,
                          fontSize: "13px",
                          fontFamily: fontStack,
                          fontWeight: 500,
                          letterSpacing: "0.01em",
                          padding: "0 16px",
                          height: "42px",
                          borderRadius: "3px",
                          textDecoration: "none",
                          transition: "border-color 150ms, color 150ms",
                          flexShrink: 0,
                          flex: "1 1 auto",
                          justifyContent: "center",
                        }}
                        onMouseEnter={(e) => {
                          const el = e.currentTarget;
                          el.style.borderColor = T.body;
                          el.style.color = T.headline;
                        }}
                        onMouseLeave={(e) => {
                          const el = e.currentTarget;
                          el.style.borderColor = T.border;
                          el.style.color = T.body;
                        }}
                        onFocus={(e) => {
                          const el = e.currentTarget;
                          el.style.borderColor = T.body;
                          el.style.color = T.headline;
                          el.style.outline = `2px solid ${T.cyan}`;
                          el.style.outlineOffset = "2px";
                        }}
                        onBlur={(e) => {
                          const el = e.currentTarget;
                          el.style.borderColor = T.border;
                          el.style.color = T.body;
                          el.style.outline = "none";
                        }}
                      >
                        <Github size={14} />
                        View on GitHub
                      </a>
                    </div>

                    {/* Installation guide link */}
                    <a
                      href="https://github.com/Lfmpaes/klyric/blob/main/docs/installation.md"
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label="Read the KLyric installation guide"
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "5px",
                        color: T.body,
                        fontSize: "12px",
                        fontFamily: fontStack,
                        textDecoration: "none",
                        transition: "color 150ms",
                        marginBottom: "24px",
                      }}
                      onMouseEnter={(e) => ((e.currentTarget).style.color = T.cyanBright)}
                      onMouseLeave={(e) => ((e.currentTarget).style.color = T.body)}
                      onFocus={(e) => {
                        (e.currentTarget).style.color = T.cyanBright;
                        (e.currentTarget).style.outline = `2px solid ${T.cyan}`;
                        (e.currentTarget).style.outlineOffset = "2px";
                        (e.currentTarget).style.borderRadius = "2px";
                      }}
                      onBlur={(e) => {
                        (e.currentTarget).style.color = T.body;
                        (e.currentTarget).style.outline = "none";
                      }}
                    >
                      Read the installation guide
                      <ArrowRight size={12} />
                    </a>

                    {/* Badges */}
                    <div
                      style={{
                        display: "flex",
                        flexWrap: "wrap" as const,
                        gap: "6px",
                        alignItems: "center",
                      }}
                    >
                      {["Plasma 6", "Cider", "Local only", "MIT License"].map((b) => (
                        <Badge key={b}>{b}</Badge>
                      ))}
                      <span
                        style={{
                          color: T.body,
                          fontSize: "11px",
                          fontFamily: monoStack,
                          opacity: 0.5,
                          marginLeft: "4px",
                        }}
                      >
                        v0.1.0
                      </span>
                    </div>
                  </section>

                  {/* ── Right column ─── */}
                  <section aria-label="Plasma panel preview" style={{ minWidth: 0, overflow: "hidden" }}>
                    <PlasmaPreview />
                  </section>
                </div>

                {/* Architecture strip */}
                <div style={{ marginTop: "36px" }}>
                  <ArchStrip />
                </div>
              </div>
            </article>
          </div>
        </main>

        {/* ── Footer ─────────────────────────────────────────────────── */}
        <footer
          style={{
            borderTop: `1px solid ${T.border}`,
            minHeight: "68px",
            display: "flex",
            alignItems: "center",
          }}
        >
          <div
            style={{
              maxWidth: "920px",
              margin: "0 auto",
              width: "100%",
              padding: "0 24px",
              display: "flex",
              flexWrap: "wrap" as const,
              alignItems: "center",
              justifyContent: "space-between",
              gap: "12px",
            }}
          >
            <span
              style={{
                color: T.body,
                fontSize: "12px",
                fontFamily: fontStack,
                opacity: 0.6,
              }}
            >
              KLyric is released under the MIT License.
            </span>
            <div style={{ display: "flex", gap: "20px", alignItems: "center" }}>
              <span style={{ color: T.body, fontSize: "12px", fontFamily: fontStack, opacity: 0.6 }}>
                Built by{" "}
                <a
                  href="https://luizpaes.dev"
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    color: T.body,
                    textDecoration: "underline",
                    transition: "color 150ms",
                  }}
                  onMouseEnter={(e) => ((e.currentTarget).style.color = T.cyanBright)}
                  onMouseLeave={(e) => ((e.currentTarget).style.color = T.body)}
                >
                  Luiz Paes
                </a>
              </span>
              <a
                href="https://github.com/Lfmpaes/klyric"
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  color: T.body,
                  fontSize: "12px",
                  fontFamily: fontStack,
                  textDecoration: "underline",
                  opacity: 0.6,
                  transition: "color 150ms, opacity 150ms",
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget).style.color = T.cyanBright;
                  (e.currentTarget).style.opacity = "1";
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget).style.color = T.body;
                  (e.currentTarget).style.opacity = "0.6";
                }}
              >
                Source code
              </a>
            </div>
          </div>
        </footer>
      </div>

      {/* ── Responsive styles ─────────────────────────────────────────── */}
      <style>{`
        @media (max-width: 700px) {
          .hero-grid {
            grid-template-columns: 1fr !important;
          }
        }

        @media (max-width: 480px) {
          header {
            height: 56px !important;
          }
          nav span {
            display: none;
          }
        }

        @media (prefers-reduced-motion: reduce) {
          * {
            transition-duration: 0ms !important;
            animation-duration: 0ms !important;
          }
        }

        * {
          box-sizing: border-box;
        }

        a:focus-visible {
          outline: 2px solid ${T.cyan};
          outline-offset: 2px;
          border-radius: 2px;
        }
      `}</style>
    </div>
  );
}
